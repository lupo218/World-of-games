from os import system

def clear():
    system('cls')   # Screen_cleaner

SCORES_FILE_NAME = 'Scores.txt'
BAD_RETURN_CODE = 0


